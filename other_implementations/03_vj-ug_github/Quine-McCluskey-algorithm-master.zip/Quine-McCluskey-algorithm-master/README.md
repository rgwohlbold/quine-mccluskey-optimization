# Quine-McCluskey-algorithm 

Full upload from computer

Quine–McCluskey algorithm implementation in C, C++ and C#

- Method used for minimization of boolean functions
- Functionality is identical to Karnaugh mapping, but more efficient for use in computer algorithms
- Also gives a deterministic way to check that the minimal form of a Boolean function 

To Do
-Python 

Here is another great implementation to understand it http://frederic.carpon.perso.sfr.fr/Quine-McCluskey_(frederic_carpon_implementation).php

